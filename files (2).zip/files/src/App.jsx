import React from 'react'
import { useAppStore } from './store'
import Navbar from './components/Navbar'
import HomeScreen from './components/HomeScreen'
import VideoEditor from './components/VideoEditor'
import PhotoEditor from './components/PhotoEditor'
import AudioEditor from './components/AudioEditor'
import './index.css'

function App() {
  const currentEditor = useAppStore((state) => state.currentEditor)

  return (
    <div className="w-screen h-screen flex flex-col bg-dark-950">
      <Navbar />
      <div className="flex-1 overflow-hidden">
        {currentEditor === 'home' && <HomeScreen />}
        {currentEditor === 'video' && <VideoEditor />}
        {currentEditor === 'photo' && <PhotoEditor />}
        {currentEditor === 'audio' && <AudioEditor />}
      </div>
    </div>
  )
}

export default App
