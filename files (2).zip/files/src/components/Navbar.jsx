import React, { useEffect } from 'react'
import { useAppStore } from '../store'

const Navbar = () => {
  const { currentEditor, setCurrentEditor, undo, redo } = useAppStore()

  useEffect(() => {
    const handleKeyPress = (e) => {
      // Ctrl/Cmd + Z for undo
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault()
        undo()
      }
      // Ctrl/Cmd + Shift + Z for redo
      if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'y') && e.shiftKey) {
        e.preventDefault()
        redo()
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [undo, redo])

  return (
    <nav className="bg-dark-900 border-b border-dark-700 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="text-2xl font-bold text-blue-500">✨ Media Editor</div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex gap-2">
          <button
            onClick={() => setCurrentEditor('home')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              currentEditor === 'home'
                ? 'bg-blue-600 text-white'
                : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => setCurrentEditor('video')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              currentEditor === 'video'
                ? 'bg-blue-600 text-white'
                : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
            }`}
          >
            Video
          </button>
          <button
            onClick={() => setCurrentEditor('photo')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              currentEditor === 'photo'
                ? 'bg-blue-600 text-white'
                : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
            }`}
          >
            Photo
          </button>
          <button
            onClick={() => setCurrentEditor('audio')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              currentEditor === 'audio'
                ? 'bg-blue-600 text-white'
                : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
            }`}
          >
            Audio
          </button>
        </div>
      </div>

      <div className="text-xs text-dark-400">
        <span className="mr-4">⌘Z Undo • ⌘⇧Z Redo</span>
      </div>
    </nav>
  )
}

export default Navbar
