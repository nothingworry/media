import React, { useState } from 'react'
import { 
  cropImage, 
  rotateImage, 
  flipImage, 
  resizeImage,
  applyFilter,
  drawText,
  drawShape
} from '../utils/imageProcessing'

const PhotoToolbar = ({ image, setImage, canvasRef }) => {
  const [showCropModal, setShowCropModal] = useState(false)
  const [showResizeModal, setShowResizeModal] = useState(false)
  const [showTextModal, setShowTextModal] = useState(false)
  const [cropValues, setCropValues] = useState({ x: 0, y: 0, width: 100, height: 100 })
  const [resizeValues, setResizeValues] = useState({ width: image?.width, height: image?.height })
  const [textValues, setTextValues] = useState({ text: 'Text', fontSize: 32, color: '#ffffff' })

  const updateCanvas = (newImage) => {
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d')
      canvasRef.current.width = newImage.width
      canvasRef.current.height = newImage.height
      ctx.drawImage(newImage, 0, 0)
    }
    setImage(newImage)
  }

  const handleRotate = (degrees) => {
    const rotated = rotateImage(canvasRef.current, degrees)
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = rotated.toDataURL()
  }

  const handleFlip = (direction) => {
    const flipped = flipImage(canvasRef.current, direction)
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = flipped.toDataURL()
  }

  const handleCrop = () => {
    const cropped = cropImage(canvasRef.current, cropValues.x, cropValues.y, cropValues.width, cropValues.height)
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = cropped.toDataURL()
    setShowCropModal(false)
  }

  const handleResize = () => {
    const resized = resizeImage(canvasRef.current, resizeValues.width, resizeValues.height)
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = resized.toDataURL()
    setShowResizeModal(false)
  }

  const handleFilter = (filterName, value) => {
    const filtered = applyFilter(canvasRef.current, filterName, value)
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = filtered.toDataURL()
  }

  const handleAddText = () => {
    drawText(canvasRef.current, textValues.text, {
      fontSize: textValues.fontSize,
      fillColor: textValues.color
    })
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = canvasRef.current.toDataURL()
    setShowTextModal(false)
  }

  const handleAddShape = (shape) => {
    drawShape(canvasRef.current, shape, {
      x: 50,
      y: 50,
      width: 100,
      height: 100,
      fillColor: '#3b82f6',
      strokeColor: '#1e40af',
      strokeWidth: 2
    })
    const newImage = new Image()
    newImage.onload = () => updateCanvas(newImage)
    newImage.src = canvasRef.current.toDataURL()
  }

  return (
    <div className="bg-dark-900 rounded-lg p-4 border border-dark-700 space-y-4">
      <h3 className="font-semibold text-white mb-4">Editing Tools</h3>

      {/* Transform Tools */}
      <div className="space-y-2">
        <p className="text-xs font-medium text-dark-300 mb-2">Transform</p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => handleRotate(90)}
            className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
          >
            ↻ Rotate 90°
          </button>
          <button
            onClick={() => handleRotate(-90)}
            className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
          >
            ↺ Rotate -90°
          </button>
          <button
            onClick={() => handleFlip('horizontal')}
            className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
          >
            ↔️ Flip H
          </button>
          <button
            onClick={() => handleFlip('vertical')}
            className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
          >
            ↕️ Flip V
          </button>
        </div>
        <button
          onClick={() => setShowCropModal(true)}
          className="w-full bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
        >
          ✂️ Crop
        </button>
        <button
          onClick={() => setShowResizeModal(true)}
          className="w-full bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
        >
          📏 Resize
        </button>
      </div>

      {/* Filter Tools */}
      <div className="border-t border-dark-700 pt-4 space-y-2">
        <p className="text-xs font-medium text-dark-300 mb-2">Filters</p>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => handleFilter('brightness', 120)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">☀️ Bright</button>
          <button onClick={() => handleFilter('contrast', 120)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">◐ Contrast</button>
          <button onClick={() => handleFilter('saturation', 150)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">🎨 Saturate</button>
          <button onClick={() => handleFilter('grayscale', 100)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">⬜ B&W</button>
          <button onClick={() => handleFilter('sepia', 100)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">🟫 Sepia</button>
          <button onClick={() => handleFilter('blur', 5)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">〰️ Blur</button>
          <button onClick={() => handleFilter('invert', 100)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">⚫ Invert</button>
          <button onClick={() => handleFilter('hueRotate', 180)} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">🔄 Hue</button>
        </div>
      </div>

      {/* Draw Tools */}
      <div className="border-t border-dark-700 pt-4 space-y-2">
        <p className="text-xs font-medium text-dark-300 mb-2">Draw</p>
        <button
          onClick={() => setShowTextModal(true)}
          className="w-full bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-xs transition-colors"
        >
          📝 Add Text
        </button>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => handleAddShape('rectangle')} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">▭ Rectangle</button>
          <button onClick={() => handleAddShape('circle')} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">● Circle</button>
          <button onClick={() => handleAddShape('triangle')} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">△ Triangle</button>
          <button onClick={() => handleAddShape('line')} className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded text-xs">/ Line</button>
        </div>
      </div>

      {/* Crop Modal */}
      {showCropModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-4 max-w-sm w-full border border-dark-700">
            <h3 className="text-lg font-bold text-white mb-4">Crop Image</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-dark-300 mb-1">X</label>
                <input type="number" value={cropValues.x} onChange={(e) => setCropValues({...cropValues, x: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Y</label>
                <input type="number" value={cropValues.y} onChange={(e) => setCropValues({...cropValues, y: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Width</label>
                <input type="number" value={cropValues.width} onChange={(e) => setCropValues({...cropValues, width: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Height</label>
                <input type="number" value={cropValues.height} onChange={(e) => setCropValues({...cropValues, height: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setShowCropModal(false)} className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded text-sm transition-colors">Cancel</button>
              <button onClick={handleCrop} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm transition-colors">Apply</button>
            </div>
          </div>
        </div>
      )}

      {/* Resize Modal */}
      {showResizeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-4 max-w-sm w-full border border-dark-700">
            <h3 className="text-lg font-bold text-white mb-4">Resize Image</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-dark-300 mb-1">Width (px)</label>
                <input type="number" value={resizeValues.width} onChange={(e) => setResizeValues({...resizeValues, width: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Height (px)</label>
                <input type="number" value={resizeValues.height} onChange={(e) => setResizeValues({...resizeValues, height: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setShowResizeModal(false)} className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded text-sm transition-colors">Cancel</button>
              <button onClick={handleResize} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm transition-colors">Apply</button>
            </div>
          </div>
        </div>
      )}

      {/* Text Modal */}
      {showTextModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-4 max-w-sm w-full border border-dark-700">
            <h3 className="text-lg font-bold text-white mb-4">Add Text</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm text-dark-300 mb-1">Text</label>
                <input type="text" value={textValues.text} onChange={(e) => setTextValues({...textValues, text: e.target.value})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" placeholder="Enter text" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Font Size</label>
                <input type="number" value={textValues.fontSize} onChange={(e) => setTextValues({...textValues, fontSize: parseInt(e.target.value)})} className="w-full bg-dark-800 border border-dark-600 rounded px-2 py-1 text-white text-sm" min="8" max="200" />
              </div>
              <div>
                <label className="block text-sm text-dark-300 mb-1">Color</label>
                <input type="color" value={textValues.color} onChange={(e) => setTextValues({...textValues, color: e.target.value})} className="w-full bg-dark-800 border border-dark-600 rounded p-1 cursor-pointer h-10" />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button onClick={() => setShowTextModal(false)} className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded text-sm transition-colors">Cancel</button>
              <button onClick={handleAddText} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm transition-colors">Add</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default PhotoToolbar
