import React, { useEffect, useState } from 'react'

const PhotoCanvas = ({ image, canvasRef }) => {
  const [scale, setScale] = useState(1)
  const [panX, setPanX] = useState(0)
  const [panY, setPanY] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const containerRef = React.useRef(null)

  useEffect(() => {
    if (!image || !canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    
    // Set canvas size to match image
    canvas.width = image.width
    canvas.height = image.height

    // Draw image
    ctx.drawImage(image, 0, 0)
  }, [image])

  const handleWheel = (e) => {
    e.preventDefault()
    const newScale = Math.max(0.1, Math.min(5, scale - e.deltaY * 0.001))
    setScale(newScale)
  }

  const handleMouseDown = (e) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX - panX, y: e.clientY - panY })
  }

  const handleMouseMove = (e) => {
    if (!isDragging) return
    setPanX(e.clientX - dragStart.x)
    setPanY(e.clientY - dragStart.y)
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const resetView = () => {
    setScale(1)
    setPanX(0)
    setPanY(0)
  }

  return (
    <div
      ref={containerRef}
      className="w-full h-full bg-dark-900 rounded-lg border border-dark-700 overflow-hidden flex flex-col"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Canvas Viewer */}
      <div className="flex-1 bg-pattern relative flex items-center justify-center overflow-hidden cursor-move">
        <svg
          ref={canvasRef}
          style={{
            transform: `translate(${panX}px, ${panY}px) scale(${scale})`,
            transformOrigin: 'center',
            transition: isDragging ? 'none' : 'transform 0.1s ease-out'
          }}
          className="shadow-lg"
        />
        <canvas
          ref={canvasRef}
          style={{
            transform: `translate(${panX}px, ${panY}px) scale(${scale})`,
            transformOrigin: 'center',
            transition: isDragging ? 'none' : 'transform 0.1s ease-out'
          }}
          className="shadow-lg max-w-none max-h-none"
        />
      </div>

      {/* Bottom Info Bar */}
      <div className="bg-dark-800 border-t border-dark-700 px-4 py-3 flex items-center justify-between text-xs text-dark-400">
        <div>
          {image && (
            <>
              <span className="mr-4">{image.width} × {image.height}px</span>
              <span className="mr-4">Zoom: {Math.round(scale * 100)}%</span>
            </>
          )}
        </div>
        <div className="flex gap-2">
          <button
            onClick={resetView}
            className="bg-dark-700 hover:bg-dark-600 text-white px-2 py-1 rounded transition-colors text-xs"
          >
            Reset View
          </button>
          <span className="text-dark-500">Scroll to zoom • Drag to pan</span>
        </div>
      </div>
    </div>
  )
}

export default PhotoCanvas
