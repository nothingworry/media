import React, { useRef, useEffect, useState } from 'react'

const AudioWaveform = ({ waveform, duration, currentTime, onSeek, clipName }) => {
  const canvasRef = useRef(null)
  const containerRef = useRef(null)
  const [scale, setScale] = useState(1)
  const [panX, setPanX] = useState(0)
  const [isDragging, setIsDragging] = useState(false)

  useEffect(() => {
    if (!canvasRef.current || !waveform) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    
    // Clear canvas
    ctx.fillStyle = 'rgb(15, 15, 15)'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Draw grid
    ctx.strokeStyle = 'rgb(55, 65, 81)'
    ctx.lineWidth = 0.5
    
    const secondWidth = (canvas.width / duration) * scale
    for (let i = 0; i <= duration; i++) {
      const x = i * secondWidth + panX
      if (x < 0 || x > canvas.width) continue
      
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvas.height)
      ctx.stroke()
      
      // Draw time label every 5 seconds
      if (i % 5 === 0) {
        ctx.fillStyle = 'rgb(107, 114, 128)'
        ctx.font = '10px monospace'
        ctx.textAlign = 'center'
        ctx.fillText(`${i}s`, x, 15)
      }
    }

    // Draw waveform image
    if (waveform) {
      const img = new Image()
      img.onload = () => {
        const width = img.width * scale
        const x = panX
        ctx.drawImage(img, x, 25, width, canvas.height - 50)
      }
      img.src = waveform
    }

    // Draw playhead
    const playheadX = (currentTime / duration) * canvas.width
    ctx.strokeStyle = 'rgb(239, 68, 68)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(playheadX, 0)
    ctx.lineTo(playheadX, canvas.height)
    ctx.stroke()

    // Draw current time label
    ctx.fillStyle = 'rgb(239, 68, 68)'
    ctx.font = 'bold 12px monospace'
    ctx.textAlign = 'center'
    const timeStr = `${Math.floor(currentTime / 60)}:${Math.floor(currentTime % 60).toString().padStart(2, '0')}`
    ctx.fillText(timeStr, playheadX, canvas.height - 5)
  }, [waveform, duration, currentTime, scale, panX])

  const handleCanvasClick = (e) => {
    if (!containerRef.current) return
    
    const rect = containerRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const time = (x / rect.width) * duration
    onSeek(Math.max(0, Math.min(duration, time)))
  }

  const handleWheel = (e) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault()
      const newScale = Math.max(1, Math.min(10, scale - e.deltaY * 0.01))
      setScale(newScale)
    }
  }

  const resetZoom = () => {
    setScale(1)
    setPanX(0)
  }

  return (
    <div className="w-full h-full flex flex-col bg-dark-900 overflow-hidden">
      {/* Waveform Canvas */}
      <div
        ref={containerRef}
        className="flex-1 relative cursor-pointer overflow-hidden"
        onWheel={handleWheel}
      >
        <canvas
          ref={canvasRef}
          width={1200}
          height={200}
          onClick={handleCanvasClick}
          className="w-full h-full"
        />
      </div>

      {/* Info Bar */}
      <div className="bg-dark-800 border-t border-dark-700 px-4 py-3 flex items-center justify-between text-xs text-dark-400">
        <div>
          <span className="font-medium text-white">{clipName}</span>
          <span className="mx-2">•</span>
          <span>Duration: {(duration || 0).toFixed(2)}s</span>
          <span className="mx-2">•</span>
          <span>Zoom: {scale.toFixed(1)}x</span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={resetZoom}
            className="bg-dark-700 hover:bg-dark-600 text-white px-2 py-1 rounded transition-colors text-xs"
          >
            Reset Zoom
          </button>
          <span className="text-dark-500">Click to seek • Scroll+Ctrl to zoom</span>
        </div>
      </div>
    </div>
  )
}

export default AudioWaveform
