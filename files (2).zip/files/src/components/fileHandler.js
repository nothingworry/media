export const SUPPORTED_FORMATS = {
  video: ['mp4', 'webm', 'mov', 'avi'],
  audio: ['mp3', 'wav', 'aac', 'm4a', 'flac'],
  image: ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp']
}

export const validateFile = (file) => {
  const extension = file.name.split('.').pop().toLowerCase()
  
  if (SUPPORTED_FORMATS.video.includes(extension)) {
    return { type: 'video', isValid: true, error: null }
  }
  if (SUPPORTED_FORMATS.audio.includes(extension)) {
    return { type: 'audio', isValid: true, error: null }
  }
  if (SUPPORTED_FORMATS.image.includes(extension)) {
    return { type: 'image', isValid: true, error: null }
  }
  
  return {
    type: null,
    isValid: false,
    error: `File type ".${extension}" is not supported. Supported formats: ${Object.values(SUPPORTED_FORMATS).flat().join(', ')}`
  }
}

export const getFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

export const fileToBase64 = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = error => reject(error)
    reader.readAsDataURL(file)
  })
}

export const createThumbnail = async (file, type) => {
  if (type === 'image') {
    return fileToBase64(file)
  }
  
  if (type === 'video') {
    return generateVideoThumbnail(file)
  }
  
  if (type === 'audio') {
    return 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"%3E%3Ccircle cx="50" cy="50" r="40" fill="%234b5563"/%3E%3Cpath d="M45 35 L45 65 L60 50 Z" fill="%23e5e7eb"/%3E%3C/svg%3E'
  }
  
  return null
}

export const generateVideoThumbnail = (file) => {
  return new Promise((resolve) => {
    const video = document.createElement('video')
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    
    video.onloadedmetadata = () => {
      canvas.width = 160
      canvas.height = 90
      video.currentTime = Math.min(video.duration * 0.1, 5) // Thumbnail at 10% or 5s
    }
    
    video.onseeked = () => {
      try {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
        resolve(canvas.toDataURL('image/jpeg', 0.7))
      } catch (e) {
        resolve('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 90"%3E%3Crect width="160" height="90" fill="%234b5563"/%3E%3Ctext x="50%" y="50%" text-anchor="middle" dy=".3em" fill="%23e5e7eb" font-size="12"%3EVideo%3C/text%3E%3C/svg%3E')
      }
    }
    
    video.onerror = () => {
      resolve('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 90"%3E%3Crect width="160" height="90" fill="%234b5563"/%3E%3C/svg%3E')
    }
    
    video.src = URL.createObjectURL(file)
  })
}
