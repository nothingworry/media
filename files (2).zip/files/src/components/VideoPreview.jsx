import React, { useRef, useEffect, useState } from 'react'
import { useAppStore } from '../store'

const VideoPreview = () => {
  const {
    videoClips,
    selectedClipId,
    isPlaying,
    currentTime,
    duration,
    setIsPlaying,
    setCurrentTime,
    setDuration
  } = useAppStore()

  const videoRef = useRef(null)
  const containerRef = useRef(null)
  const [volume, setVolume] = useState(1)

  const selectedClip = videoClips.find(clip => clip.id === selectedClipId) || videoClips[0]

  useEffect(() => {
    const video = videoRef.current
    if (!video || !selectedClip) return

    video.src = selectedClip.url
    video.volume = volume

    if (isPlaying) {
      video.play().catch(() => {
        setIsPlaying(false)
      })
    } else {
      video.pause()
    }

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
    }

    const handleLoadedMetadata = () => {
      setDuration(video.duration)
    }

    const handleEnded = () => {
      setIsPlaying(false)
    }

    video.addEventListener('timeupdate', handleTimeUpdate)
    video.addEventListener('loadedmetadata', handleLoadedMetadata)
    video.addEventListener('ended', handleEnded)

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate)
      video.removeEventListener('loadedmetadata', handleLoadedMetadata)
      video.removeEventListener('ended', handleEnded)
    }
  }, [selectedClip, isPlaying, volume, setCurrentTime, setDuration, setIsPlaying])

  const togglePlayback = () => {
    setIsPlaying(!isPlaying)
  }

  const handleSeek = (time) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time
      setCurrentTime(time)
    }
  }

  const formatTime = (seconds) => {
    if (!seconds || !isFinite(seconds)) return '0:00'
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="w-full h-full flex flex-col bg-dark-900">
      {selectedClip ? (
        <>
          <div className="flex-1 bg-black flex items-center justify-center relative overflow-hidden">
            <video
              ref={videoRef}
              className="max-w-full max-h-full"
              onContextMenu={(e) => e.preventDefault()}
            />
            
            {/* Playback Controls Overlay */}
            <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity flex items-end bg-gradient-to-t from-black/60 to-transparent">
              <div className="w-full p-4 space-y-2">
                {/* Progress Bar */}
                <div className="flex gap-2 items-center text-xs text-white">
                  <span>{formatTime(currentTime)}</span>
                  <input
                    type="range"
                    min="0"
                    max={duration || 0}
                    value={currentTime}
                    onChange={(e) => handleSeek(parseFloat(e.target.value))}
                    className="flex-1 slider"
                  />
                  <span>{formatTime(duration)}</span>
                </div>

                {/* Control Buttons */}
                <div className="flex gap-4 items-center">
                  <button
                    onClick={togglePlayback}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    {isPlaying ? '⏸ Pause' : '▶ Play'}
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-xs">🔊</span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={volume}
                      onChange={(e) => setVolume(parseFloat(e.target.value))}
                      className="w-24 slider"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Info Bar */}
          <div className="bg-dark-800 border-t border-dark-700 px-4 py-3 text-sm">
            <p className="text-dark-300">
              <span className="font-medium text-white">{selectedClip.name}</span>
              {' • '}
              <span>{selectedClip.duration.toFixed(1)}s</span>
              {' • '}
              <span className="text-xs bg-dark-700 px-2 py-1 rounded">{selectedClip.type.toUpperCase()}</span>
            </p>
          </div>
        </>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-dark-400">
          <div className="text-center">
            <div className="text-4xl mb-2">🎬</div>
            <p>Import a video clip to start editing</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default VideoPreview
