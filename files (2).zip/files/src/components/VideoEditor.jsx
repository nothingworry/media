import React, { useState, useRef, useEffect } from 'react'
import { useAppStore } from '../store'
import { validateFile, getFileSize, createThumbnail } from '../utils/fileHandler'
import VideoTimeline from './VideoTimeline'
import VideoPreview from './VideoPreview'
import VideoProperties from './VideoProperties'

const VideoEditor = () => {
  const {
    videoClips,
    selectedClipId,
    currentTime,
    isPlaying,
    duration,
    addVideoClip,
    removeVideoClip,
    setCurrentEditor,
  } = useAppStore()

  const [showExportModal, setShowExportModal] = useState(false)
  const [exportSettings, setExportSettings] = useState({
    format: 'mp4',
    resolution: '1080p',
    quality: 'high'
  })
  const fileInputRef = useRef(null)

  const handleFileImport = async (e) => {
    const files = Array.from(e.target.files)
    
    for (const file of files) {
      const validation = validateFile(file)
      
      if (!validation.isValid) {
        alert(validation.error)
        continue
      }

      if (validation.type === 'video' || validation.type === 'audio') {
        const video = document.createElement('video')
        const url = URL.createObjectURL(file)
        
        video.onloadedmetadata = async () => {
          const thumbnail = await createThumbnail(file, validation.type)
          
          addVideoClip({
            name: file.name,
            file: file,
            url: url,
            type: validation.type,
            duration: video.duration,
            thumbnail: thumbnail,
            startTime: 0,
            endTime: video.duration,
            position: videoClips.length * 10
          })
        }
        
        video.onerror = () => {
          alert(`Failed to load: ${file.name}`)
        }
        
        video.src = url
      }
    }
  }

  const handleExport = async () => {
    if (videoClips.length === 0) {
      alert('Please add at least one clip to export')
      return
    }

    // In a real app, this would use FFmpeg.wasm or a server-side API
    alert(`Export started:\nFormat: ${exportSettings.format}\nResolution: ${exportSettings.resolution}\nQuality: ${exportSettings.quality}\n\nNote: Full export requires FFmpeg integration`)
    setShowExportModal(false)
  }

  return (
    <div className="flex h-full gap-4 p-4 bg-dark-950">
      {/* Sidebar */}
      <div className="w-64 flex flex-col gap-4">
        {/* Import Section */}
        <div className="bg-dark-900 rounded-lg p-4 border border-dark-700">
          <h3 className="font-semibold text-white mb-3">Import Media</h3>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="video/*,audio/*"
            onChange={handleFileImport}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors mb-2"
          >
            + Add Files
          </button>
          <p className="text-xs text-dark-400">
            Supports: MP4, WebM, MOV, AVI, MP3, WAV, AAC
          </p>
        </div>

        {/* Clips List */}
        <div className="bg-dark-900 rounded-lg p-4 border border-dark-700 flex-1 flex flex-col">
          <h3 className="font-semibold text-white mb-3">Clips ({videoClips.length})</h3>
          <div className="space-y-2 flex-1 overflow-y-auto">
            {videoClips.length === 0 ? (
              <p className="text-dark-400 text-sm">No clips added yet</p>
            ) : (
              videoClips.map((clip) => (
                <div
                  key={clip.id}
                  className="bg-dark-800 p-2 rounded border border-dark-600 hover:border-blue-500 transition-colors"
                >
                  {clip.thumbnail && (
                    <img src={clip.thumbnail} alt={clip.name} className="w-full h-20 object-cover rounded mb-2" />
                  )}
                  <p className="text-xs text-white truncate font-medium">{clip.name}</p>
                  <p className="text-xs text-dark-400">{clip.duration.toFixed(1)}s • {getFileSize(clip.file.size)}</p>
                  <button
                    onClick={() => removeVideoClip(clip.id)}
                    className="mt-2 w-full text-xs bg-red-600 hover:bg-red-700 text-white py-1 rounded transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Export Button */}
        <button
          onClick={() => setShowExportModal(true)}
          disabled={videoClips.length === 0}
          className="w-full bg-green-600 hover:bg-green-700 disabled:bg-dark-700 disabled:cursor-not-allowed text-white py-2 rounded-lg transition-colors font-semibold"
        >
          📥 Export Project
        </button>
      </div>

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Preview */}
        <div className="flex-1 bg-dark-900 rounded-lg border border-dark-700 overflow-hidden">
          <VideoPreview />
        </div>

        {/* Timeline */}
        <div className="h-48 bg-dark-900 rounded-lg border border-dark-700 overflow-hidden">
          <VideoTimeline clips={videoClips} />
        </div>

        {/* Properties */}
        <div className="h-40 bg-dark-900 rounded-lg border border-dark-700 overflow-auto">
          <VideoProperties />
        </div>
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-6 max-w-md w-full border border-dark-700">
            <h2 className="text-2xl font-bold text-white mb-4">Export Video</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-dark-300 mb-2">Format</label>
                <select
                  value={exportSettings.format}
                  onChange={(e) => setExportSettings({...exportSettings, format: e.target.value})}
                  className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="mp4">MP4 (H.264)</option>
                  <option value="webm">WebM (VP8/VP9)</option>
                  <option value="mov">MOV (ProRes)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-dark-300 mb-2">Resolution</label>
                <select
                  value={exportSettings.resolution}
                  onChange={(e) => setExportSettings({...exportSettings, resolution: e.target.value})}
                  className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="480p">480p (SD)</option>
                  <option value="720p">720p (HD)</option>
                  <option value="1080p">1080p (Full HD)</option>
                  <option value="2160p">2160p (4K)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-dark-300 mb-2">Quality</label>
                <select
                  value={exportSettings.quality}
                  onChange={(e) => setExportSettings({...exportSettings, quality: e.target.value})}
                  className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="low">Low (Fast)</option>
                  <option value="medium">Medium</option>
                  <option value="high">High (Slow)</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleExport}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors font-semibold"
              >
                Export
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default VideoEditor
