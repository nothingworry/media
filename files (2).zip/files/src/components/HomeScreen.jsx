import React from 'react'
import { useAppStore } from '../store'

const HomeScreen = () => {
  const setCurrentEditor = useAppStore((state) => state.setCurrentEditor)

  const editors = [
    {
      id: 'video',
      title: 'Video Editor',
      description: 'Create stunning videos with timeline editing, transitions, and effects',
      icon: '🎬',
      features: ['Timeline editing', 'Transitions', 'Text & captions', 'Filters & effects', 'Audio tracks']
    },
    {
      id: 'photo',
      title: 'Photo Editor',
      description: 'Enhance and edit photos with powerful tools',
      icon: '📷',
      features: ['Crop & rotate', 'Color adjustments', 'Filters', 'Text & shapes', 'Layers']
    },
    {
      id: 'audio',
      title: 'Audio Editor',
      description: 'Edit and enhance audio files with precision',
      icon: '🎵',
      features: ['Waveform editing', 'Trim & split', 'Volume control', 'Fade in/out', 'Effects']
    }
  ]

  return (
    <div className="w-full h-full bg-dark-950 flex items-center justify-center">
      <div className="max-w-6xl w-full px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-white mb-4">Welcome to Media Editor</h1>
          <p className="text-xl text-dark-400">Fast, lightweight editing for video, photo, and audio</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {editors.map((editor) => (
            <div
              key={editor.id}
              onClick={() => setCurrentEditor(editor.id)}
              className="bg-dark-900 border border-dark-700 rounded-xl p-6 hover:border-blue-500 hover:shadow-lg hover:shadow-blue-500/20 transition-all cursor-pointer group"
            >
              <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">{editor.icon}</div>
              <h2 className="text-2xl font-bold text-white mb-2">{editor.title}</h2>
              <p className="text-dark-400 mb-6">{editor.description}</p>
              <div className="space-y-2 mb-6">
                {editor.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-dark-300 text-sm">
                    <span className="text-blue-400">✓</span>
                    {feature}
                  </div>
                ))}
              </div>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors font-medium">
                Open Editor
              </button>
            </div>
          ))}
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-4 text-center text-dark-400 text-sm">
          <div className="flex items-center justify-center gap-2">
            <span>⚡</span>
            <span>Lightweight & Fast</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <span>🎯</span>
            <span>Beginner Friendly</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <span>💾</span>
            <span>Works Locally</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default HomeScreen
