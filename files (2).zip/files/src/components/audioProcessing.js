export const createAudioContext = () => {
  return new (window.AudioContext || window.webkitAudioContext)()
}

export const decodeAudio = async (arrayBuffer, audioContext) => {
  try {
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer)
    return audioBuffer
  } catch (error) {
    console.error('Error decoding audio:', error)
    throw error
  }
}

export const generateWaveform = (audioBuffer, width = 800, height = 100) => {
  const rawData = audioBuffer.getChannelData(0)
  const samples = Math.floor(rawData.length / width)
  const filteredData = []
  
  for (let i = 0; i < width; i++) {
    let sum = 0
    for (let j = 0; j < samples; j++) {
      sum += Math.abs(rawData[i * samples + j])
    }
    filteredData.push(sum / samples)
  }
  
  const multiplier = Math.max(...filteredData) > 1 ? 0.25 : 0.5
  
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')
  
  ctx.fillStyle = 'rgb(15, 15, 15)'
  ctx.fillRect(0, 0, width, height)
  
  ctx.strokeStyle = 'rgb(59, 130, 246)'
  ctx.lineWidth = 1
  ctx.beginPath()
  
  for (let i = 0; i < width; i++) {
    const barHeight = filteredData[i] * multiplier * height
    ctx.moveTo(i, height / 2 - barHeight)
    ctx.lineTo(i, height / 2 + barHeight)
  }
  
  ctx.stroke()
  return canvas.toDataURL()
}

export const createAudioFile = (audioBuffer, audioContext) => {
  const numberOfChannels = audioBuffer.numberOfChannels
  const sampleRate = audioBuffer.sampleRate
  const format = 'audio/wav'
  const bitDepth = 16
  
  const bytesPerSample = bitDepth / 8
  const blockAlign = numberOfChannels * bytesPerSample
  
  const data = audioBuffer.getChannelData(0)
  
  const WAVFile = encodeWAV(data, sampleRate)
  return new Blob([WAVFile], { type: format })
}

const encodeWAV = (samples, sampleRate) => {
  const buffer = new ArrayBuffer(44 + samples.length * 2)
  const view = new DataView(buffer)
  
  const writeString = (offset, string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i))
    }
  }
  
  writeString(0, 'RIFF')
  view.setUint32(4, 36 + samples.length * 2, true)
  writeString(8, 'WAVE')
  writeString(12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true)
  view.setUint16(22, 1, true)
  view.setUint32(24, sampleRate, true)
  view.setUint32(28, sampleRate * 2, true)
  view.setUint16(32, 2, true)
  view.setUint16(34, 16, true)
  writeString(36, 'data')
  view.setUint32(40, samples.length * 2, true)
  
  let offset = 44
  for (let i = 0; i < samples.length; i++, offset += 2) {
    const sample = Math.max(-1, Math.min(1, samples[i]))
    view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true)
  }
  
  return buffer
}

export const trimAudio = (audioBuffer, startTime, endTime, audioContext) => {
  const sampleRate = audioBuffer.sampleRate
  const startSample = Math.floor(startTime * sampleRate)
  const endSample = Math.floor(endTime * sampleRate)
  const length = endSample - startSample
  
  const trimmed = audioContext.createBuffer(
    audioBuffer.numberOfChannels,
    length,
    sampleRate
  )
  
  for (let i = 0; i < audioBuffer.numberOfChannels; i++) {
    const channelData = audioBuffer.getChannelData(i)
    trimmed.getChannelData(i).set(channelData.subarray(startSample, endSample))
  }
  
  return trimmed
}

export const getAudioDuration = (audioBuffer) => {
  return audioBuffer.duration
}

export const setAudioVolume = (gainNode, volume) => {
  gainNode.gain.setValueAtTime(volume, 0)
}

export const fadeAudio = (gainNode, startVolume, endVolume, duration, startTime = 0) => {
  const now = new (window.AudioContext || window.webkitAudioContext)().currentTime
  gainNode.gain.setValueAtTime(startVolume, now + startTime)
  gainNode.gain.linearRampToValueAtTime(endVolume, now + startTime + duration)
}
