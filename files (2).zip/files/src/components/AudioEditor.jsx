import React, { useRef, useState, useEffect } from 'react'
import { useAppStore } from '../store'
import { validateFile, getFileSize } from '../utils/fileHandler'
import { 
  createAudioContext, 
  decodeAudio, 
  generateWaveform,
  getAudioDuration
} from '../utils/audioProcessing'
import AudioWaveform from './AudioWaveform'

const AudioEditor = () => {
  const { addAudioClip, audioClips, removeAudioClip } = useAppStore()
  
  const [audioContext, setAudioContext] = useState(null)
  const [currentClip, setCurrentClip] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [waveform, setWaveform] = useState(null)
  const [volume, setVolume] = useState(1)
  const [showExportModal, setShowExportModal] = useState(false)
  const [exportFormat, setExportFormat] = useState('wav')
  
  const fileInputRef = useRef(null)
  const audioNodeRef = useRef(null)
  const playbackNodeRef = useRef(null)
  const animationFrameRef = useRef(null)

  useEffect(() => {
    if (!audioContext) {
      setAudioContext(createAudioContext())
    }
  }, [audioContext])

  const handleFileImport = async (e) => {
    const files = Array.from(e.target.files || [])
    
    for (const file of files) {
      const validation = validateFile(file)
      
      if (!validation.isValid || validation.type !== 'audio') {
        alert(validation.error || 'Please select a valid audio file')
        continue
      }

      try {
        const arrayBuffer = await file.arrayBuffer()
        const audioBuffer = await decodeAudio(arrayBuffer, audioContext)
        const waveformDataUrl = generateWaveform(audioBuffer)

        const clip = {
          name: file.name,
          file: file,
          audioBuffer: audioBuffer,
          duration: getAudioDuration(audioBuffer),
          waveform: waveformDataUrl,
          startTime: 0,
          endTime: getAudioDuration(audioBuffer),
          volume: 1,
          id: Date.now() + Math.random()
        }

        addAudioClip(clip)
        if (!currentClip) {
          setCurrentClip(clip)
          setWaveform(waveformDataUrl)
        }
      } catch (error) {
        alert(`Error loading audio: ${file.name}`)
        console.error(error)
      }
    }
  }

  const togglePlayback = async () => {
    if (!currentClip || !audioContext) return

    if (isPlaying) {
      if (playbackNodeRef.current) {
        playbackNodeRef.current.stop()
        playbackNodeRef.current = null
      }
      setIsPlaying(false)
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    } else {
      try {
        playbackNodeRef.current = audioContext.createBufferSource()
        playbackNodeRef.current.buffer = currentClip.audioBuffer
        
        const gainNode = audioContext.createGain()
        gainNode.gain.value = volume
        
        playbackNodeRef.current.connect(gainNode)
        gainNode.connect(audioContext.destination)
        
        playbackNodeRef.current.onended = () => {
          setIsPlaying(false)
          setCurrentTime(0)
        }
        
        playbackNodeRef.current.start(audioContext.currentTime, currentTime)
        setIsPlaying(true)
        
        const startTime = audioContext.currentTime - currentTime
        const updatePlayhead = () => {
          const newTime = audioContext.currentTime - startTime
          if (newTime <= currentClip.duration) {
            setCurrentTime(newTime)
            animationFrameRef.current = requestAnimationFrame(updatePlayhead)
          }
        }
        
        animationFrameRef.current = requestAnimationFrame(updatePlayhead)
      } catch (error) {
        console.error('Playback error:', error)
      }
    }
  }

  const handleSeek = (time) => {
    if (playbackNodeRef.current) {
      playbackNodeRef.current.stop()
      playbackNodeRef.current = null
    }
    setCurrentTime(time)
    if (isPlaying) {
      setIsPlaying(false)
      setTimeout(() => togglePlayback(), 100)
    }
  }

  const handleExport = () => {
    if (!currentClip) return
    
    const link = document.createElement('a')
    const url = URL.createObjectURL(currentClip.file)
    link.href = url
    link.download = `${currentClip.name.split('.')[0]}_edited.${exportFormat}`
    link.click()
    URL.revokeObjectURL(url)
    setShowExportModal(false)
  }

  const formatTime = (seconds) => {
    if (!seconds || !isFinite(seconds)) return '0:00'
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="flex h-full gap-4 p-4 bg-dark-950">
      {/* Sidebar */}
      <div className="w-64 flex flex-col gap-4">
        {/* Import Section */}
        <div className="bg-dark-900 rounded-lg p-4 border border-dark-700">
          <h3 className="font-semibold text-white mb-3">Import Audio</h3>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="audio/*"
            onChange={handleFileImport}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors mb-2"
          >
            + Add Audio
          </button>
          <p className="text-xs text-dark-400">
            Supports: MP3, WAV, AAC, M4A, FLAC
          </p>
        </div>

        {/* Clips List */}
        <div className="bg-dark-900 rounded-lg p-4 border border-dark-700 flex-1 flex flex-col">
          <h3 className="font-semibold text-white mb-3">Audio Clips ({audioClips.length})</h3>
          <div className="space-y-2 flex-1 overflow-y-auto">
            {audioClips.length === 0 ? (
              <p className="text-dark-400 text-sm">No audio clips loaded</p>
            ) : (
              audioClips.map((clip) => (
                <div
                  key={clip.id}
                  onClick={() => {
                    setCurrentClip(clip)
                    setWaveform(clip.waveform)
                    setCurrentTime(0)
                  }}
                  className={`bg-dark-800 p-3 rounded border transition-colors cursor-pointer ${
                    currentClip?.id === clip.id ? 'border-blue-500 bg-dark-700' : 'border-dark-600 hover:border-dark-500'
                  }`}
                >
                  <p className="text-xs text-white truncate font-medium">{clip.name}</p>
                  <p className="text-xs text-dark-400">{clip.duration.toFixed(1)}s • {getFileSize(clip.file.size)}</p>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      removeAudioClip(clip.id)
                      if (currentClip?.id === clip.id) {
                        setCurrentClip(null)
                        setWaveform(null)
                      }
                    }}
                    className="mt-2 w-full text-xs bg-red-600 hover:bg-red-700 text-white py-1 rounded transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Export Button */}
        <button
          onClick={() => setShowExportModal(true)}
          disabled={!currentClip}
          className="w-full bg-green-600 hover:bg-green-700 disabled:bg-dark-700 disabled:cursor-not-allowed text-white py-2 rounded-lg transition-colors font-semibold"
        >
          💾 Export Audio
        </button>
      </div>

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col gap-4">
        {currentClip ? (
          <>
            {/* Waveform */}
            <div className="flex-1 bg-dark-900 rounded-lg border border-dark-700 overflow-hidden">
              <AudioWaveform
                waveform={waveform}
                duration={currentClip.duration}
                currentTime={currentTime}
                onSeek={handleSeek}
                clipName={currentClip.name}
              />
            </div>

            {/* Playback Controls */}
            <div className="bg-dark-900 rounded-lg border border-dark-700 p-4 space-y-4">
              {/* Time Display */}
              <div className="flex items-center justify-between text-sm text-dark-300">
                <span>{formatTime(currentTime)}</span>
                <span>Duration: {formatTime(currentClip.duration)}</span>
              </div>

              {/* Progress Bar */}
              <input
                type="range"
                min="0"
                max={currentClip.duration}
                step="0.01"
                value={currentTime}
                onChange={(e) => handleSeek(parseFloat(e.target.value))}
                className="w-full slider"
              />

              {/* Controls */}
              <div className="flex items-center gap-4">
                <button
                  onClick={togglePlayback}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors font-semibold"
                >
                  {isPlaying ? '⏸ Pause' : '▶ Play'}
                </button>

                <div className="flex items-center gap-2 flex-1">
                  <span>🔊</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="flex-1 slider"
                  />
                  <span className="text-xs text-dark-400 w-10">{Math.round(volume * 100)}%</span>
                </div>
              </div>

              {/* Additional Controls */}
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-dark-700">
                <button className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-sm transition-colors">
                  ✂️ Trim
                </button>
                <button className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-sm transition-colors">
                  ⬆️ Fade In
                </button>
                <button className="bg-dark-800 hover:bg-dark-700 text-white px-3 py-2 rounded text-sm transition-colors">
                  ⬇️ Fade Out
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 bg-dark-900 rounded-lg border border-dark-700 flex items-center justify-center text-dark-400">
            <div className="text-center">
              <div className="text-4xl mb-2">🎵</div>
              <p>Import an audio file to start editing</p>
            </div>
          </div>
        )}
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-6 max-w-md w-full border border-dark-700">
            <h2 className="text-2xl font-bold text-white mb-4">Export Audio</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-dark-300 mb-2">Format</label>
                <select
                  value={exportFormat}
                  onChange={(e) => setExportFormat(e.target.value)}
                  className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="wav">WAV (Uncompressed)</option>
                  <option value="mp3">MP3 (Compressed)</option>
                  <option value="aac">AAC (Lossy)</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleExport}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors font-semibold"
              >
                Export
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AudioEditor
