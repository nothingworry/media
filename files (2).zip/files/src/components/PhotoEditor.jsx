import React, { useRef, useState, useEffect } from 'react'
import { useAppStore } from '../store'
import { validateFile } from '../utils/fileHandler'
import PhotoCanvas from './PhotoCanvas'
import PhotoToolbar from './PhotoToolbar'

const PhotoEditor = () => {
  const [image, setImage] = useState(null)
  const [originalImage, setOriginalImage] = useState(null)
  const canvasRef = useRef(null)
  const fileInputRef = useRef(null)
  const [showExportModal, setShowExportModal] = useState(false)
  const [exportFormat, setExportFormat] = useState('png')

  const handleFileImport = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return

    const validation = validateFile(file)
    if (!validation.isValid || validation.type !== 'image') {
      alert(validation.error || 'Please select a valid image file')
      return
    }

    const reader = new FileReader()
    reader.onload = (event) => {
      const img = new Image()
      img.onload = () => {
        setOriginalImage(img)
        setImage(img)
      }
      img.src = event.target.result
    }
    reader.readAsDataURL(file)
  }

  const handleExport = () => {
    if (!canvasRef.current) return

    const link = document.createElement('a')
    link.href = canvasRef.current.toDataURL(`image/${exportFormat}`)
    link.download = `edited-image.${exportFormat}`
    link.click()
    setShowExportModal(false)
  }

  return (
    <div className="flex h-full gap-4 p-4 bg-dark-950">
      {/* Toolbar */}
      <div className="w-64 flex flex-col gap-4">
        {/* Import Section */}
        <div className="bg-dark-900 rounded-lg p-4 border border-dark-700">
          <h3 className="font-semibold text-white mb-3">Open Image</h3>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileImport}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors mb-2"
          >
            📁 Open Image
          </button>
          <p className="text-xs text-dark-400">
            Supports: JPG, PNG, GIF, WebP, BMP
          </p>
        </div>

        {/* Tools */}
        {image && (
          <>
            <PhotoToolbar image={image} setImage={setImage} canvasRef={canvasRef} />

            {/* Export Button */}
            <button
              onClick={() => setShowExportModal(true)}
              className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors font-semibold"
            >
              💾 Export
            </button>
          </>
        )}
      </div>

      {/* Canvas Area */}
      <div className="flex-1">
        {image ? (
          <PhotoCanvas image={image} canvasRef={canvasRef} />
        ) : (
          <div className="w-full h-full bg-dark-900 rounded-lg border border-dark-700 flex items-center justify-center text-dark-400">
            <div className="text-center">
              <div className="text-4xl mb-2">📷</div>
              <p>Open an image to start editing</p>
            </div>
          </div>
        )}
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-dark-900 rounded-lg p-6 max-w-md w-full border border-dark-700">
            <h2 className="text-2xl font-bold text-white mb-4">Export Image</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm text-dark-300 mb-2">Format</label>
                <select
                  value={exportFormat}
                  onChange={(e) => setExportFormat(e.target.value)}
                  className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-white text-sm"
                >
                  <option value="png">PNG (Lossless)</option>
                  <option value="jpg">JPG (Compressed)</option>
                  <option value="webp">WebP (Modern)</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="flex-1 bg-dark-700 hover:bg-dark-600 text-white py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleExport}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-colors font-semibold"
              >
                Export
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default PhotoEditor
