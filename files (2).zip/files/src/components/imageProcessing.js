export const ImageFilters = {
  brightness: (ctx, value) => {
    ctx.filter = `brightness(${value}%)`
  },
  
  contrast: (ctx, value) => {
    ctx.filter = `contrast(${value}%)`
  },
  
  saturation: (ctx, value) => {
    ctx.filter = `saturate(${value}%)`
  },
  
  hueRotate: (ctx, value) => {
    ctx.filter = `hue-rotate(${value}deg)`
  },
  
  sepia: (ctx, value) => {
    ctx.filter = `sepia(${value}%)`
  },
  
  grayscale: (ctx, value) => {
    ctx.filter = `grayscale(${value}%)`
  },
  
  blur: (ctx, value) => {
    ctx.filter = `blur(${value}px)`
  },
  
  invert: (ctx, value) => {
    ctx.filter = `invert(${value}%)`
  }
}

export const canvasToBlob = (canvas) => {
  return new Promise((resolve, reject) => {
    canvas.toBlob(resolve, 'image/png')
  })
}

export const cropImage = (canvas, x, y, width, height) => {
  const newCanvas = document.createElement('canvas')
  const ctx = newCanvas.getContext('2d')
  newCanvas.width = width
  newCanvas.height = height
  ctx.drawImage(canvas, x, y, width, height, 0, 0, width, height)
  return newCanvas
}

export const rotateImage = (canvas, degrees) => {
  const rad = (degrees * Math.PI) / 180
  const width = canvas.width
  const height = canvas.height
  
  const newCanvas = document.createElement('canvas')
  newCanvas.width = Math.abs(width * Math.cos(rad)) + Math.abs(height * Math.sin(rad))
  newCanvas.height = Math.abs(width * Math.sin(rad)) + Math.abs(height * Math.cos(rad))
  
  const ctx = newCanvas.getContext('2d')
  ctx.translate(newCanvas.width / 2, newCanvas.height / 2)
  ctx.rotate(rad)
  ctx.drawImage(canvas, -width / 2, -height / 2)
  
  return newCanvas
}

export const flipImage = (canvas, direction) => {
  const newCanvas = document.createElement('canvas')
  const ctx = newCanvas.getContext('2d')
  newCanvas.width = canvas.width
  newCanvas.height = canvas.height
  
  ctx.translate(direction === 'horizontal' ? canvas.width : 0, direction === 'vertical' ? canvas.height : 0)
  ctx.scale(direction === 'horizontal' ? -1 : 1, direction === 'vertical' ? -1 : 1)
  ctx.drawImage(canvas, 0, 0)
  
  return newCanvas
}

export const resizeImage = (canvas, width, height) => {
  const newCanvas = document.createElement('canvas')
  const ctx = newCanvas.getContext('2d')
  newCanvas.width = width
  newCanvas.height = height
  ctx.drawImage(canvas, 0, 0, width, height)
  return newCanvas
}

export const applyFilter = (canvas, filterName, value) => {
  const newCanvas = document.createElement('canvas')
  const ctx = newCanvas.getContext('2d')
  newCanvas.width = canvas.width
  newCanvas.height = canvas.height
  
  if (ImageFilters[filterName]) {
    ImageFilters[filterName](ctx, value)
  }
  
  ctx.drawImage(canvas, 0, 0)
  return newCanvas
}

export const drawText = (canvas, text, options = {}) => {
  const ctx = canvas.getContext('2d')
  const {
    x = canvas.width / 2,
    y = canvas.height / 2,
    fontSize = 32,
    fontFamily = 'Arial',
    fillColor = '#ffffff',
    strokeColor = '#000000',
    strokeWidth = 0,
    align = 'center',
    baseline = 'middle'
  } = options
  
  ctx.font = `${fontSize}px ${fontFamily}`
  ctx.fillStyle = fillColor
  ctx.textAlign = align
  ctx.textBaseline = baseline
  
  if (strokeWidth > 0) {
    ctx.strokeStyle = strokeColor
    ctx.lineWidth = strokeWidth
    ctx.strokeText(text, x, y)
  }
  
  ctx.fillText(text, x, y)
  return canvas
}

export const drawShape = (canvas, shape, options = {}) => {
  const ctx = canvas.getContext('2d')
  const { x = 10, y = 10, width = 50, height = 50, fillColor = '#ffffff', strokeColor = null, strokeWidth = 0 } = options
  
  ctx.fillStyle = fillColor
  if (strokeColor) {
    ctx.strokeStyle = strokeColor
    ctx.lineWidth = strokeWidth
  }
  
  switch (shape) {
    case 'rectangle':
      ctx.fillRect(x, y, width, height)
      if (strokeColor) ctx.strokeRect(x, y, width, height)
      break
    case 'circle':
      ctx.beginPath()
      ctx.arc(x + width / 2, y + height / 2, width / 2, 0, 2 * Math.PI)
      ctx.fill()
      if (strokeColor) ctx.stroke()
      break
    case 'line':
      ctx.beginPath()
      ctx.moveTo(x, y)
      ctx.lineTo(x + width, y + height)
      ctx.stroke()
      break
    case 'triangle':
      ctx.beginPath()
      ctx.moveTo(x + width / 2, y)
      ctx.lineTo(x + width, y + height)
      ctx.lineTo(x, y + height)
      ctx.closePath()
      ctx.fill()
      if (strokeColor) ctx.stroke()
      break
  }
  
  return canvas
}
