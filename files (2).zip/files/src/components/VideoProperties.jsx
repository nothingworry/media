import React, { useState } from 'react'
import { useAppStore } from '../store'

const VideoProperties = () => {
  const { videoClips, selectedClipId, updateVideoClip } = useAppStore()
  const selectedClip = videoClips.find(clip => clip.id === selectedClipId)

  if (!selectedClip) {
    return (
      <div className="w-full h-full flex items-center justify-center text-dark-400">
        <p>Select a clip to view properties</p>
      </div>
    )
  }

  const [properties, setProperties] = useState({
    volume: 1,
    opacity: 1,
    brightness: 100,
    contrast: 100,
    saturation: 100,
    speed: 1
  })

  const handlePropertyChange = (key, value) => {
    setProperties(prev => ({
      ...prev,
      [key]: value
    }))
    updateVideoClip(selectedClip.id, {
      ...selectedClip,
      [key]: value
    })
  }

  return (
    <div className="w-full h-full bg-dark-900 overflow-auto">
      <div className="p-4 space-y-4">
        <h3 className="text-lg font-semibold text-white">Clip Properties</h3>

        {/* Clip Info */}
        <div className="bg-dark-800 rounded p-3 text-sm text-dark-300">
          <p><strong>{selectedClip.name}</strong></p>
          <p>Duration: {selectedClip.duration.toFixed(2)}s</p>
          <p>Type: {selectedClip.type.toUpperCase()}</p>
        </div>

        {/* Volume Control */}
        <div className="space-y-2">
          <label className="block text-sm text-dark-300">Volume</label>
          <div className="flex items-center gap-2">
            <span>🔇</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={properties.volume}
              onChange={(e) => handlePropertyChange('volume', parseFloat(e.target.value))}
              className="flex-1 slider"
            />
            <span className="text-xs text-dark-400 w-8">{Math.round(properties.volume * 100)}%</span>
          </div>
        </div>

        {/* Opacity Control */}
        <div className="space-y-2">
          <label className="block text-sm text-dark-300">Opacity</label>
          <div className="flex items-center gap-2">
            <span>👁️</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={properties.opacity}
              onChange={(e) => handlePropertyChange('opacity', parseFloat(e.target.value))}
              className="flex-1 slider"
            />
            <span className="text-xs text-dark-400 w-8">{Math.round(properties.opacity * 100)}%</span>
          </div>
        </div>

        {/* Speed Control */}
        <div className="space-y-2">
          <label className="block text-sm text-dark-300">Playback Speed</label>
          <div className="flex items-center gap-2">
            <span>⏱️</span>
            <input
              type="range"
              min="0.25"
              max="2"
              step="0.25"
              value={properties.speed}
              onChange={(e) => handlePropertyChange('speed', parseFloat(e.target.value))}
              className="flex-1 slider"
            />
            <span className="text-xs text-dark-400 w-12">{properties.speed.toFixed(2)}x</span>
          </div>
        </div>

        {/* Color Adjustments */}
        <div className="border-t border-dark-700 pt-4">
          <h4 className="text-sm font-medium text-white mb-3">Color Adjustments</h4>

          <div className="space-y-2">
            <label className="block text-sm text-dark-300">Brightness</label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="50"
                max="150"
                step="5"
                value={properties.brightness}
                onChange={(e) => handlePropertyChange('brightness', parseInt(e.target.value))}
                className="flex-1 slider"
              />
              <span className="text-xs text-dark-400 w-8">{properties.brightness}%</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm text-dark-300">Contrast</label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="50"
                max="150"
                step="5"
                value={properties.contrast}
                onChange={(e) => handlePropertyChange('contrast', parseInt(e.target.value))}
                className="flex-1 slider"
              />
              <span className="text-xs text-dark-400 w-8">{properties.contrast}%</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm text-dark-300">Saturation</label>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min="0"
                max="200"
                step="5"
                value={properties.saturation}
                onChange={(e) => handlePropertyChange('saturation', parseInt(e.target.value))}
                className="flex-1 slider"
              />
              <span className="text-xs text-dark-400 w-8">{properties.saturation}%</span>
            </div>
          </div>
        </div>

        {/* Transition Options */}
        <div className="border-t border-dark-700 pt-4">
          <h4 className="text-sm font-medium text-white mb-3">Transitions</h4>
          <select className="w-full bg-dark-800 border border-dark-600 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500">
            <option>None</option>
            <option>Fade</option>
            <option>Slide Left</option>
            <option>Slide Right</option>
            <option>Slide Down</option>
            <option>Slide Up</option>
            <option>Zoom In</option>
            <option>Zoom Out</option>
            <option>Cross Dissolve</option>
          </select>
        </div>
      </div>
    </div>
  )
}

export default VideoProperties
