import React, { useState } from 'react'
import { useAppStore } from '../store'

const VideoTimeline = ({ clips }) => {
  const { setSelectedClipId, selectedClipId, updateVideoClip, currentTime } = useAppStore()
  const [draggedClip, setDraggedClip] = useState(null)
  const [resizingClip, setResizingClip] = useState(null)
  const timelineRef = React.useRef(null)
  
  const totalDuration = clips.reduce((sum, clip) => sum + (clip.endTime - clip.startTime), 0) || 10
  const pixelsPerSecond = 100

  const getClipWidth = (clip) => {
    return (clip.endTime - clip.startTime) * pixelsPerSecond
  }

  const getClipPosition = (clip) => {
    return clip.position * pixelsPerSecond
  }

  const handleDragStart = (e, clip) => {
    setDraggedClip(clip)
    e.dataTransfer.effectAllowed = 'move'
  }

  const handleDragOver = (e) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
  }

  const handleDrop = (e) => {
    e.preventDefault()
    if (!draggedClip || !timelineRef.current) return

    const rect = timelineRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const newPosition = x / pixelsPerSecond

    updateVideoClip(draggedClip.id, {
      position: Math.max(0, newPosition)
    })

    setDraggedClip(null)
  }

  const handleResizeStart = (e, clip, direction) => {
    e.preventDefault()
    e.stopPropagation()
    setResizingClip({ clip, direction, startX: e.clientX })
  }

  React.useEffect(() => {
    if (!resizingClip) return

    const handleMouseMove = (e) => {
      const delta = e.clientX - resizingClip.startX
      const deltaTime = delta / pixelsPerSecond

      if (resizingClip.direction === 'left') {
        const newStartTime = Math.max(0, resizingClip.clip.startTime + deltaTime)
        if (newStartTime < resizingClip.clip.endTime) {
          updateVideoClip(resizingClip.clip.id, {
            startTime: newStartTime
          })
        }
      } else {
        const newEndTime = Math.max(resizingClip.clip.startTime, resizingClip.clip.endTime + deltaTime)
        updateVideoClip(resizingClip.clip.id, {
          endTime: newEndTime
        })
      }

      setResizingClip({
        ...resizingClip,
        startX: e.clientX
      })
    }

    const handleMouseUp = () => {
      setResizingClip(null)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [resizingClip, updateVideoClip])

  return (
    <div className="w-full h-full flex flex-col bg-dark-900 overflow-hidden">
      {/* Timeline Ruler */}
      <div className="h-8 bg-dark-800 border-b border-dark-700 flex items-center px-4 text-xs text-dark-400 overflow-x-auto">
        {Array.from({ length: Math.ceil(totalDuration) + 1 }).map((_, i) => (
          <div key={i} style={{ width: pixelsPerSecond }}>
            {i}s
          </div>
        ))}
      </div>

      {/* Clips Area */}
      <div
        ref={timelineRef}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className="flex-1 bg-dark-900 relative overflow-x-auto"
        style={{ minHeight: '150px' }}
      >
        {/* Playhead */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
          style={{ left: currentTime * pixelsPerSecond }}
        />

        {clips.length === 0 ? (
          <div className="absolute inset-0 flex items-center justify-center text-dark-400">
            <p>Drag clips here to arrange them on the timeline</p>
          </div>
        ) : (
          <div className="relative" style={{ width: (totalDuration + 2) * pixelsPerSecond }}>
            {clips.map((clip) => (
              <div
                key={clip.id}
                draggable
                onDragStart={(e) => handleDragStart(e, clip)}
                onClick={() => setSelectedClipId(clip.id)}
                className={`absolute top-4 bottom-4 bg-blue-700 border border-blue-600 rounded cursor-move group transition-all ${
                  selectedClipId === clip.id ? 'ring-2 ring-yellow-500' : ''
                }`}
                style={{
                  left: getClipPosition(clip),
                  width: getClipWidth(clip),
                  minWidth: '40px'
                }}
              >
                {/* Clip Content */}
                <div className="w-full h-full p-2 flex items-center overflow-hidden">
                  {clip.thumbnail && (
                    <img
                      src={clip.thumbnail}
                      alt={clip.name}
                      className="h-full w-auto object-cover rounded opacity-70 group-hover:opacity-100 transition-opacity"
                    />
                  )}
                  <div className="flex-1 ml-2 min-w-0">
                    <p className="text-xs font-medium text-white truncate">{clip.name}</p>
                    <p className="text-xs text-dark-200">
                      {(clip.endTime - clip.startTime).toFixed(1)}s
                    </p>
                  </div>
                </div>

                {/* Resize Handles */}
                <div
                  onMouseDown={(e) => handleResizeStart(e, clip, 'left')}
                  className="absolute left-0 top-0 bottom-0 w-1 bg-yellow-500 opacity-0 group-hover:opacity-100 cursor-ew-resize transition-opacity"
                />
                <div
                  onMouseDown={(e) => handleResizeStart(e, clip, 'right')}
                  className="absolute right-0 top-0 bottom-0 w-1 bg-yellow-500 opacity-0 group-hover:opacity-100 cursor-ew-resize transition-opacity"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Info Bar */}
      <div className="bg-dark-800 border-t border-dark-700 px-4 py-2 text-xs text-dark-400">
        <span>{clips.length} clips • Total duration: {totalDuration.toFixed(1)}s</span>
      </div>
    </div>
  )
}

export default VideoTimeline
