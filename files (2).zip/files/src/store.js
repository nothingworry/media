import { create } from 'zustand'

export const useAppStore = create((set) => ({
  // Current editor mode
  currentEditor: 'home', // 'home', 'video', 'photo', 'audio'
  
  // Media/Project state
  mediaItems: [],
  currentProject: null,
  
  // Video editor state
  videoClips: [],
  videoTrack: [],
  audioTrack: [],
  currentTime: 0,
  duration: 0,
  isPlaying: false,
  selectedClipId: null,
  
  // Photo editor state
  photoCanvas: null,
  photoLayers: [],
  
  // Audio editor state
  audioClips: [],
  audioWaveformData: {},
  
  // UI state
  darkMode: true,
  showTimeline: false,
  showPreview: true,
  
  // History for undo/redo
  history: [],
  historyIndex: -1,
  
  // Actions
  setCurrentEditor: (editor) => set({ currentEditor: editor }),
  addMediaItem: (item) => set((state) => ({
    mediaItems: [...state.mediaItems, { ...item, id: Date.now() }]
  })),
  removeMediaItem: (id) => set((state) => ({
    mediaItems: state.mediaItems.filter(m => m.id !== id)
  })),
  
  // Video editor actions
  addVideoClip: (clip) => set((state) => ({
    videoClips: [...state.videoClips, { ...clip, id: Date.now() }]
  })),
  updateVideoClip: (id, updates) => set((state) => ({
    videoClips: state.videoClips.map(clip => clip.id === id ? { ...clip, ...updates } : clip)
  })),
  removeVideoClip: (id) => set((state) => ({
    videoClips: state.videoClips.filter(clip => clip.id !== id)
  })),
  setCurrentTime: (time) => set({ currentTime: time }),
  setIsPlaying: (playing) => set({ isPlaying: playing }),
  setSelectedClipId: (id) => set({ selectedClipId: id }),
  setDuration: (duration) => set({ duration }),
  
  // Photo editor actions
  addPhotoLayer: (layer) => set((state) => ({
    photoLayers: [...state.photoLayers, { ...layer, id: Date.now() }]
  })),
  updatePhotoLayer: (id, updates) => set((state) => ({
    photoLayers: state.photoLayers.map(layer => layer.id === id ? { ...layer, ...updates } : layer)
  })),
  removePhotoLayer: (id) => set((state) => ({
    photoLayers: state.photoLayers.filter(layer => layer.id !== id)
  })),
  
  // Audio editor actions
  addAudioClip: (clip) => set((state) => ({
    audioClips: [...state.audioClips, { ...clip, id: Date.now() }]
  })),
  removeAudioClip: (id) => set((state) => ({
    audioClips: state.audioClips.filter(clip => clip.id !== id)
  })),
  setAudioWaveformData: (id, data) => set((state) => ({
    audioWaveformData: { ...state.audioWaveformData, [id]: data }
  })),
  
  // History/Undo-Redo
  pushHistory: (state) => set((prevState) => ({
    history: [...prevState.history.slice(0, prevState.historyIndex + 1), state],
    historyIndex: prevState.historyIndex + 1
  })),
  undo: () => set((state) => {
    if (state.historyIndex > 0) {
      const previousState = state.history[state.historyIndex - 1]
      return { ...previousState, historyIndex: state.historyIndex - 1 }
    }
    return state
  }),
  redo: () => set((state) => {
    if (state.historyIndex < state.history.length - 1) {
      const nextState = state.history[state.historyIndex + 1]
      return { ...nextState, historyIndex: state.historyIndex + 1 }
    }
    return state
  }),
  
  // Reset for new project
  resetProject: () => set({
    mediaItems: [],
    videoClips: [],
    videoTrack: [],
    audioTrack: [],
    currentTime: 0,
    duration: 0,
    isPlaying: false,
    selectedClipId: null,
    photoCanvas: null,
    photoLayers: [],
    audioClips: [],
    audioWaveformData: {},
    history: [],
    historyIndex: -1
  })
}))
