# Quick Start Guide - Media Editor

## 60-Second Setup

```bash
# 1. Install Node.js from nodejs.org (if needed)

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev

# Opens http://localhost:5173 automatically
```

**That's it!** The editor is running.

## What Just Happened?

1. **npm install** downloaded:
   - React (UI framework)
   - Zustand (state management)
   - Tailwind CSS (styling)
   - Vite (build tool)

2. **npm run dev** started:
   - Local dev server at port 5173
   - Hot reload when you save files
   - Auto-opens in browser

## Try It Out

1. Click **Video** button
2. Click **+ Add Files** and select a video/audio file
3. Watch it appear in the clips list
4. Click the clip to preview it
5. Drag on the timeline to resize the clip

## Project Structure at a Glance

```
src/
├── components/          # React components
│   ├── App.jsx         # Main app
│   ├── VideoEditor.jsx # Video editing
│   ├── PhotoEditor.jsx # Photo editing
│   └── AudioEditor.jsx # Audio editing
├── utils/              # Helper functions
│   ├── fileHandler.js  # File validation
│   ├── imageProcessing.js
│   └── audioProcessing.js
├── store.js            # Global state (Zustand)
└── index.css           # Tailwind styles
```

## Common Tasks

### Add a New Video Filter

**File:** `src/utils/imageProcessing.js`

```javascript
export const ImageFilters = {
  // ... existing filters
  yourNewFilter: (ctx, value) => {
    ctx.filter = `your-css-filter(${value}%)`
  }
}
```

**File:** `src/components/PhotoToolbar.jsx`

```jsx
<button
  onClick={() => handleFilter('yourNewFilter', 50)}
  className="bg-dark-800 hover:bg-dark-700 text-white px-2 py-1 rounded"
>
  ✨ Your Filter
</button>
```

### Add a New Button

```jsx
// Add to appropriate component
<button
  onClick={() => console.log('clicked')}
  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors"
>
  📌 My Button
</button>
```

### Update Global State

```javascript
// In a component
import { useAppStore } from '../store'

const MyComponent = () => {
  const { videoClips, addVideoClip } = useAppStore()
  
  const handleAdd = () => {
    addVideoClip({ name: 'test', duration: 5 })
  }
  
  return <button onClick={handleAdd}>Add</button>
}
```

### Add a New Editor Mode

1. **Create component:** `src/components/MyEditor.jsx`
2. **Add to store:** `setCurrentEditor('myEditor')`
3. **Add to App.jsx:**
```jsx
{currentEditor === 'myEditor' && <MyEditor />}
```
4. **Add button to Navbar.jsx:**
```jsx
<button onClick={() => setCurrentEditor('myEditor')}>My Editor</button>
```

## Debugging

### View State Changes
```javascript
// Add to any component
import { useAppStore } from '../store'

const store = useAppStore()
console.log('Current state:', store)
```

### Check Console Errors
- Press `F12` to open Developer Tools
- Click **Console** tab
- Look for red error messages

### Test Canvas Operations
```javascript
// In PhotoEditor or related
console.log('Canvas:', canvasRef.current)
console.log('Image data:', canvasRef.current.toDataURL().substring(0, 50))
```

## Build for Production

```bash
# Creates optimized files in dist/
npm run build

# Test the production build locally
npx http-server dist
# Opens at http://localhost:8080
```

## Folder-by-Folder Breakdown

### `/src/components`
React components rendering the UI. Each editor (Video, Photo, Audio) has 2-3 related components.

**Naming convention:** ComponentName.jsx

### `/src/utils`
Pure functions for file handling, image processing, audio processing. No React code here.

**Why separate?** Easier to test, reuse, and maintain.

### `/src/store.js`
Zustand store - global state management.

**Store is simple:**
1. State object (what data exists)
2. Actions (functions to modify state)
3. Components use `useAppStore()` hook to access

### `/src/index.css`
Tailwind CSS imports and custom component classes.

## Keyboard Shortcuts to Add

```javascript
// In Navbar.jsx useEffect
useEffect(() => {
  const handleKeyPress = (e) => {
    // Ctrl+Z for undo
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
      e.preventDefault()
      undo()
    }
    // Add more shortcuts here
  }
  window.addEventListener('keydown', handleKeyPress)
  return () => window.removeEventListener('keydown', handleKeyPress)
}, [undo])
```

## Common Mistakes to Avoid

### ❌ Mutating State Directly
```javascript
// DON'T do this
state.videoClips[0].name = 'New Name'
```

### ✅ Create New Objects
```javascript
// DO this
updateVideoClip(id, { name: 'New Name' })
```

### ❌ Missing Dependencies
```javascript
// DON'T do this - will run every render
useEffect(() => {
  setCurrentTime(0)
}, [])
```

### ✅ Specify Dependencies
```javascript
// DO this
useEffect(() => {
  setCurrentTime(0)
}, [videoClips]) // Re-run when videoClips changes
```

## Performance Tips

### 1. Avoid Creating Objects in Render
```javascript
// BAD - creates new object every render
const options = { volume: 0.5 }

// GOOD - create once
const options = useMemo(() => ({ volume: 0.5 }), [])
```

### 2. Memoize Expensive Components
```javascript
// For heavy components that receive same props
const VideoPreview = React.memo(({ clip }) => ...)
```

### 3. Use Zustand Selectors
```javascript
// GOOD - only re-render if videoClips changes
const videoClips = useAppStore(state => state.videoClips)

// AVOID - re-renders on any store change
const store = useAppStore()
```

## File Encoding & Formats

### Video
- **Supported:** MP4, WebM, MOV, AVI
- **Browser constraint:** Limited to file format support
- **Future:** Add FFmpeg for format conversion

### Audio
- **Supported:** MP3, WAV, AAC, M4A, FLAC
- **Processing:** Web Audio API handles most formats
- **Export:** Currently exports original file

### Image
- **Supported:** JPG, PNG, GIF, WebP, BMP
- **Processing:** Canvas API
- **Performance:** Canvas limits ~8K resolution

## Troubleshooting Quick Reference

| Problem | Solution |
|---------|----------|
| App won't start | `npm install && npm run dev` |
| "Cannot find module" | `npm install` again |
| File won't import | Check format is supported |
| Playback choppy | Close other tabs, smaller file |
| Export is slow | Try smaller file or lower quality |
| Styles look wrong | `npm run dev` rebuilds CSS |

## Next Steps

1. **Read ARCHITECTURE.md** for deep dive into how it works
2. **Read README.md** for feature list and limitations
3. **Explore the code** - Start in `src/components/App.jsx`
4. **Make small changes** - Add a button, modify a color
5. **Build something** - Add a new editor or feature

## File Size Goals

- **Bundle size:** <200KB gzipped
- **Dev dependencies:** Only Vite + Tailwind
- **Runtime dependencies:** React, Zustand

## Resources

- **React:** https://react.dev
- **Zustand:** https://github.com/pmndrs/zustand
- **Tailwind:** https://tailwindcss.com
- **Vite:** https://vitejs.dev
- **Canvas API:** https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API
- **Web Audio API:** https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API

## Need Help?

1. Check ARCHITECTURE.md for system design
2. Look at existing code for patterns
3. Check browser console (F12) for errors
4. Test in different browser
5. Check if file format is supported

---

**Happy Hacking! 🎬📷🎵**

Remember: The app runs entirely in your browser. No server required!
