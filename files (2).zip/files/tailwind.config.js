export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
          600: '#4b5563',
          700: '#374151',
          750: '#252f3f',
          800: '#1f2937',
          850: '#1a202c',
          900: '#111827',
          950: '#0f0f0f',
        }
      },
    },
  },
  plugins: [],
}
